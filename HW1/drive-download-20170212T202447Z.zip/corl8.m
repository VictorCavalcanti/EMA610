function [CO]=corl8(PHI1,PHI2,M)
CO = PHI1'*M*PHI2;
end